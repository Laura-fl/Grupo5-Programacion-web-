/**
 * Manejo de datos de productos
 */

// Base de datos de productos
const ProductosDB = {
    1: {
        id: 1,
        nombre: 'Blazer lino orgánico alma verde',
        descripcion: 'Blazer oversize de lino orgánico teñido con técnicas sostenibles. Perfecto para looks casuales y formales.',
        precio: 129,
        precioOriginal: 189,
        imagen: 'https://placehold.co/400x500/e5e9e2/2d3a2b?text=Blazer',
        categoria: 'Vestidos sostenibles',
        estado: 'Como nuevo',
        circularidad: 92,
        tallas: ['XS', 'S', 'M', 'L'],
        colores: ['Verde', 'Beige'],
        material: 'Lino orgánico 100%',
        impactoCO2: 2.1,
        historial: 'Prenda de temporada Otoño 2023, usada 3 veces'
    },
    2: {
        id: 2,
        nombre: 'Denim vintage lavado índigo',
        descripcion: 'Jeans rectos unisex restaurados con técnica de lavado artesanal. Corte clásico que nunca pasa de moda.',
        precio: 89,
        precioOriginal: 139,
        imagen: 'https://placehold.co/400x500/cbd3c7/2d3a2b?text=Denim',
        categoria: 'Denim circular',
        estado: 'Buen estado',
        circularidad: 88,
        tallas: ['XS', 'S', 'M', 'L', 'XL'],
        colores: ['Azul índigo', 'Azul claro'],
        material: 'Algodón reciclado 85%, Elastano 15%',
        impactoCO2: 1.8,
        historial: 'Jeans de edición limitada 2022'
    },
    3: {
        id: 3,
        nombre: 'Sudadera reciclada bosque urbano',
        descripcion: 'Sudadera unisex fabricada con algodón reciclado y procesos de bajo impacto ambiental. Cómoda y sostenible.',
        precio: 69,
        precioOriginal: 99,
        imagen: 'https://placehold.co/400x500/94a68e/f4f6f3?text=Sudadera',
        categoria: 'Athleisure eco',
        estado: 'Nuevo',
        circularidad: 94,
        tallas: ['S', 'M', 'L', 'XL'],
        colores: ['Verde bosque', 'Gris cemento'],
        material: 'Algodón reciclado 100%',
        impactoCO2: 1.2,
        historial: 'Nueva con etiquetas, producción consciente'
    },
    4: {
        id: 4,
        nombre: 'Vestido midi algodón orgánico',
        descripcion: 'Vestido midi de algodón orgánico con estampado botánico. Ideal para ocasiones especiales y uso diario.',
        precio: 79,
        precioOriginal: 119,
        imagen: 'https://placehold.co/400x500/e5e9e2/2d3a2b?text=Vestido',
        categoria: 'Vestidos sostenibles',
        estado: 'Como nuevo',
        circularidad: 90,
        tallas: ['XS', 'S', 'M'],
        colores: ['Blanco', 'Azul claro'],
        material: 'Algodón orgánico 100%',
        impactoCO2: 1.5,
        historial: 'Usado una vez en evento especial'
    },
    5: {
        id: 5,
        nombre: 'Camiseta básica tinte natural',
        descripcion: 'Camiseta básica unisex teñida con pigmentos naturales. Corte regular y tejido suave al tacto.',
        precio: 29,
        precioOriginal: 45,
        imagen: 'https://placehold.co/400x500/cbd3c7/2d3a2b?text=Camiseta',
        categoria: 'Basics sostenibles',
        estado: 'Nuevo',
        circularidad: 96,
        tallas: ['XS', 'S', 'M', 'L', 'XL'],
        colores: ['Natural', 'Terracota', 'Verde musgo'],
        material: 'Algodón orgánico 95%, Tencel 5%',
        impactoCO2: 0.8,
        historial: 'Producción local de bajo impacto'
    },
    6: {
        id: 6,
        nombre: 'Falda plisada lino reciclado',
        descripcion: 'Falda plisada de lino reciclado con vuelo elegante. Perfecta para crear looks sofisticados y frescos.',
        precio: 65,
        precioOriginal: 95,
        imagen: 'https://placehold.co/400x500/94a68e/f4f6f3?text=Falda',
        categoria: 'Vestidos sostenibles',
        estado: 'Buen estado',
        circularidad: 87,
        tallas: ['XS', 'S', 'M'],
        colores: ['Crudo', 'Rosa palo'],
        material: 'Lino reciclado 100%',
        impactoCO2: 1.3,
        historial: 'Prenda de temporada Verano 2023'
    }
};

/**
 * Obtiene un producto por ID
 */
function obtenerProducto(id) {
    return ProductosDB[id];
}

/**
 * Obtiene todos los productos
 */
function obtenerTodosProductos() {
    return Object.values(ProductosDB);
}

/**
 * Filtra productos por categoría
 */
function filtrarProductos(filtros = {}) {
    let productos = obtenerTodosProductos();
    
    if (filtros.categoria && filtros.categoria !== 'Todas') {
        productos = productos.filter(p => p.categoria === filtros.categoria);
    }
    
    if (filtros.precioMax) {
        productos = productos.filter(p => p.precio <= filtros.precioMax);
    }
    
    if (filtros.estado && filtros.estado.length > 0) {
        productos = productos.filter(p => filtros.estado.includes(p.estado));
    }
    
    if (filtros.tallas && filtros.tallas.length > 0) {
        productos = productos.filter(p => 
            p.tallas.some(talla => filtros.tallas.includes(talla))
        );
    }
    
    if (filtros.busqueda) {
        const termino = filtros.busqueda.toLowerCase();
        productos = productos.filter(p => 
            p.nombre.toLowerCase().includes(termino) ||
            p.descripcion.toLowerCase().includes(termino) ||
            p.categoria.toLowerCase().includes(termino)
        );
    }
    
    return productos;
}

/**
 * Obtiene productos sugeridos (excluyendo los pasados)
 */
function obtenerProductosSugeridos(excluirIds = []) {
    const todosProductos = obtenerTodosProductos();
    return todosProductos
        .filter(p => !excluirIds.includes(p.id))
        .sort(() => Math.random() - 0.5)
        .slice(0, 3);
}

// Exportar para uso global
window.ProductosDB = ProductosDB;
window.obtenerProducto = obtenerProducto;
window.obtenerTodosProductos = obtenerTodosProductos;
window.filtrarProductos = filtrarProductos;
window.obtenerProductosSugeridos = obtenerProductosSugeridos;