/**
 * Utilidades generales para GreenCloset
 */

/**
 * Formatea un precio con separadores de miles
 */
function formatearPrecio(precio) {
    return new Intl.NumberFormat('es-ES', {
        style: 'currency',
        currency: 'USD'
    }).format(precio);
}

/**
 * Formatea un número con separadores de miles
 */
function formatearNumero(numero) {
    return new Intl.NumberFormat('es-ES').format(numero);
}

/**
 * Calcula el porcentaje de descuento
 */
function calcularDescuento(precioOriginal, precioActual) {
    return Math.round(((precioOriginal - precioActual) / precioOriginal) * 100);
}

/**
 * Obtiene el nombre del mes
 */
function obtenerNombreMes(fecha) {
    const meses = [
        'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
        'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'
    ];
    return meses[fecha.getMonth()];
}

/**
 * Formatea una fecha de manera legible
 */
function formatearFecha(fechaISO) {
    const fecha = new Date(fechaISO);
    return `${fecha.getDate()} de ${obtenerNombreMes(fecha)} de ${fecha.getFullYear()}`;
}

/**
 * Debounce function para optimizar eventos
 */
function debounce(func, wait, immediate) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            timeout = null;
            if (!immediate) func(...args);
        };
        const callNow = immediate && !timeout;
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
        if (callNow) func(...args);
    };
}

/**
 * Throttle function para limitar la frecuencia de ejecución
 */
function throttle(func, limit) {
    let inThrottle;
    return function(...args) {
        if (!inThrottle) {
            func.apply(this, args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    };
}

/**
 * Valida un email
 */
function validarEmail(email) {
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return regex.test(email);
}

/**
 * Sanitiza un string para prevenir XSS
 */
function sanitizarHTML(str) {
    const temp = document.createElement('div');
    temp.textContent = str;
    return temp.innerHTML;
}

/**
 * Copia texto al portapapeles
 */
async function copiarAlPortapapeles(texto) {
    try {
        await navigator.clipboard.writeText(texto);
        return true;
    } catch (err) {
        // Fallback para navegadores más antiguos
        const textArea = document.createElement('textarea');
        textArea.value = texto;
        document.body.appendChild(textArea);
        textArea.select();
        document.execCommand('copy');
        document.body.removeChild(textArea);
        return true;
    }
}

/**
 * Genera un ID único
 */
function generarIdUnico() {
    return Date.now().toString(36) + Math.random().toString(36).substr(2);
}

/**
 * Calcula el tiempo transcurrido de manera legible
 */
function tiempoTranscurrido(fecha) {
    const ahora = new Date();
    const diferencia = ahora - new Date(fecha);
    
    const segundos = Math.floor(diferencia / 1000);
    const minutos = Math.floor(segundos / 60);
    const horas = Math.floor(minutos / 60);
    const dias = Math.floor(horas / 24);
    
    if (dias > 0) return `hace ${dias} ${dias === 1 ? 'día' : 'días'}`;
    if (horas > 0) return `hace ${horas} ${horas === 1 ? 'hora' : 'horas'}`;
    if (minutos > 0) return `hace ${minutos} ${minutos === 1 ? 'minuto' : 'minutos'}`;
    return 'hace unos segundos';
}

// Exportar funciones globalmente
window.formatearPrecio = formatearPrecio;
window.formatearNumero = formatearNumero;
window.calcularDescuento = calcularDescuento;
window.formatearFecha = formatearFecha;
window.debounce = debounce;
window.throttle = throttle;
window.validarEmail = validarEmail;
window.sanitizarHTML = sanitizarHTML;
window.copiarAlPortapapeles = copiarAlPortapapeles;
window.generarIdUnico = generarIdUnico;
window.tiempoTranscurrido = tiempoTranscurrido;