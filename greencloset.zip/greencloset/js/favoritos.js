/**
 * Funcionalidades de favoritos para GreenCloset
 */

/**
 * Agrega o quita un producto de favoritos
 */
function toggleFavorito(idProducto) {
    const index = AppState.favoritos.indexOf(idProducto);
    
    if (index > -1) {
        // Quitar de favoritos
        AppState.favoritos.splice(index, 1);
        guardarEstado();
        mostrarNotificacion('Producto eliminado de favoritos', 'info');
        return false;
    } else {
        // Agregar a favoritos
        AppState.favoritos.push(idProducto);
        guardarEstado();
        mostrarNotificacion('Producto agregado a favoritos', 'success');
        return true;
    }
}

/**
 * Verifica si un producto está en favoritos
 */
function esFavorito(idProducto) {
    return AppState.favoritos.includes(idProducto);
}

/**
 * Obtiene todos los productos en favoritos
 */
function obtenerFavoritos() {
    return AppState.favoritos.map(id => obtenerProducto(id)).filter(Boolean);
}

/**
 * Calcula estadísticas de los favoritos
 */
function calcularEstadisticasFavoritos() {
    const favoritos = obtenerFavoritos();
    const totalProductos = favoritos.length;
    const totalPrecio = favoritos.reduce((sum, producto) => sum + producto.precio, 0);
    const totalAhorro = favoritos.reduce((sum, producto) => sum + (producto.precioOriginal - producto.precio), 0);
    const totalImpactoCO2 = favoritos.reduce((sum, producto) => sum + producto.impactoCO2, 0);
    
    return {
        totalProductos,
        totalPrecio,
        totalAhorro,
        totalImpactoCO2: Math.round(totalImpactoCO2 * 10) / 10
    };
}

/**
 * Renderiza la lista de favoritos
 */
function renderizarFavoritos() {
    const contenedorFavoritos = document.getElementById('contenedor-favoritos');
    const estadisticasFavoritos = document.getElementById('estadisticas-favoritos');
    
    if (!contenedorFavoritos) return;
    
    const favoritos = obtenerFavoritos();
    const estadisticas = calcularEstadisticasFavoritos();
    
    // Actualizar estadísticas
    if (estadisticasFavoritos) {
        estadisticasFavoritos.innerHTML = `
            <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mt-10">
                <div class="bg-white rounded-2xl p-6 border border-brand-100 shadow-sm transition-all duration-300 hover:shadow-lg hover:-translate-y-1 flex items-center">
                    <div class="p-3 bg-brand-100 rounded-full mr-4">
                        <svg class="w-6 h-6 text-brand-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M21 8.25c0-2.485-2.099-4.5-4.688-4.5-1.935 0-3.597 1.126-4.312 2.733-.715-1.607-2.377-2.733-4.313-2.733C5.1 3.75 3 5.765 3 8.25c0 7.22 9 12 9 12s9-4.78 9-12z"/>
                        </svg>
                    </div>
                    <div>
                        <p class="text-xs text-brand-500 uppercase font-semibold">Total Guardados</p>
                        <p class="text-2xl font-bold text-brand-800">${estadisticas.totalProductos}</p>
                        <p class="text-sm text-brand-400">Prendas listas para checkout</p>
                    </div>
                </div>
                <div class="bg-white rounded-2xl p-6 border border-brand-100 shadow-sm transition-all duration-300 hover:shadow-lg hover:-translate-y-1 flex items-center">
                    <div class="p-3 bg-brand-100 rounded-full mr-4">
                        <svg class="w-6 h-6 text-brand-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M12 21a9.004 9.004 0 008.716-6.747M12 21a9.004 9.004 0 01-8.716-6.747M12 21c2.485 0 4.5-4.03 4.5-9S14.485 3 12 3m0 18c-2.485 0-4.5-4.03-4.5-9S9.515 3 12 3m0 0a8.997 8.997 0 017.843 4.582M12 3a8.997 8.997 0 00-7.843 4.582m15.686 0A11.953 11.953 0 0112 10.5c-2.998 0-5.74-1.1-7.843-2.918m15.686 0A8.959 8.959 0 0121 12c0 .778-.099 1.533-.284 2.253m0 0A17.916 17.916 0 0112 16.5c-3.162 0-6.133-.815-8.716-2.247m0 0A9.015 9.015 0 013 12c0-1.605.42-3.113 1.157-4.418"/>
                        </svg>
                    </div>
                    <div>
                        <p class="text-xs text-brand-500 uppercase font-semibold">CO₂ Potencial</p>
                        <p class="text-2xl font-bold text-brand-800">${estadisticas.totalImpactoCO2}kg</p>
                        <p class="text-sm text-brand-400">Impacto si concretas tu lista</p>
                    </div>
                </div>
                <div class="bg-white rounded-2xl p-6 border border-brand-100 shadow-sm transition-all duration-300 hover:shadow-lg hover:-translate-y-1 flex items-center">
                    <div class="p-3 bg-brand-100 rounded-full mr-4">
                        <svg class="w-6 h-6 text-brand-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M21 12.792V21.75a2.25 2.25 0 01-2.25 2.25H5.25A2.25 2.25 0 013 21.75V12.792M21 12.792A2.25 2.25 0 0018.75 10.5H5.25a2.25 2.25 0 00-2.25 2.292m15.75-1.558a2.25 2.25 0 00-1.503-2.115l-6.75-2.115a2.25 2.25 0 00-1.986 0l-6.75 2.115A2.25 2.25 0 003 12.792v.004c0 .653.284 1.256.75 1.67l.25.223a2.25 2.25 0 001.5 2.115l6.75 2.115a2.25 2.25 0 001.986 0l6.75-2.115a2.25 2.25 0 001.5-2.115v-.004a2.25 2.25 0 00-.75-1.67l-.25-.224z"/>
                        </svg>
                    </div>
                    <div>
                        <p class="text-xs text-brand-500 uppercase font-semibold">Ahorro Total</p>
                        <p class="text-2xl font-bold text-brand-800">$${estadisticas.totalAhorro}</p>
                        <p class="text-sm text-brand-400">Vs. precios originales</p>
                    </div>
                </div>
            </div>
        `;
    }
    
    if (favoritos.length === 0) {
        contenedorFavoritos.innerHTML = `
            <div class="text-center bg-brand-100/70 border border-brand-200/60 rounded-2xl py-12 px-6">
                <svg class="mx-auto h-12 w-12 text-brand-300" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M4.318 6.318a4.5 4.5 0 016.364 0L12 7.636l1.318-1.318a4.5 4.5 0 116.364 6.364L12 20.364l-7.682-7.682a4.5 4.5 0 010-6.364z"/>
                </svg>
                <h3 class="mt-2 text-lg font-semibold text-brand-700">Tu lista de favoritos está vacía</h3>
                <p class="mt-1 text-sm text-brand-600">Haz clic en el corazón de tus prendas favoritas para guardarlas aquí.</p>
                <a href="coleccion.html" class="inline-block mt-4 bg-brand-500 text-white px-6 py-2.5 rounded-full font-semibold text-sm hover:bg-brand-600 transition-colors">
                    Descubrir Colección
                </a>
            </div>
        `;
        return;
    }
    
    let html = `
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
    `;
    
    favoritos.forEach(producto => {
        const descuento = calcularDescuento(producto.precioOriginal, producto.precio);
        
        html += `
            <div class="product-card group" data-product-id="${producto.id}">
                <div class="relative overflow-hidden rounded-lg">
                    <img src="${producto.imagen}" alt="${producto.nombre}" class="w-full h-64 object-cover transition-transform duration-300 group-hover:scale-105">
                    <div class="absolute top-2 right-2 bg-white/80 backdrop-blur-sm text-brand-700 text-xs font-semibold px-2 py-1 rounded-full">${producto.estado}</div>
                    <button class="favorito-btn absolute top-2 left-2 bg-white/80 backdrop-blur-sm p-1.5 rounded-full text-red-500 hover:bg-red-100 transition-colors"
                            data-id="${producto.id}">
                        <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/>
                        </svg>
                    </button>
                    ${descuento > 0 ? `
                        <div class="absolute top-2 right-2 bg-red-500 text-white text-xs font-bold px-2 py-1 rounded-full">
                            -${descuento}%
                        </div>
                    ` : ''}
                </div>
                <div class="mt-4">
                    <h3 class="font-semibold text-brand-800 text-sm line-clamp-2">${producto.nombre}</h3>
                    <p class="text-xs text-brand-600 mt-1 line-clamp-2">${producto.descripcion}</p>
                    <div class="flex items-center justify-between mt-3">
                        <div>
                            <span class="font-bold text-brand-700 text-lg">$${producto.precio}</span>
                            ${producto.precioOriginal > producto.precio ? `
                                <div class="text-xs text-brand-500 line-through">$${producto.precioOriginal}</div>
                            ` : ''}
                        </div>
                        <span class="text-xs text-brand-500 bg-brand-100 px-2 py-1 rounded">${producto.circularidad}% circular</span>
                    </div>
                    <div class="flex gap-2 mt-4">
                        <button onclick="agregarAlCarrito(${producto.id})" class="flex-1 bg-brand-500 text-white py-2.5 px-4 rounded-full font-semibold text-sm hover:bg-brand-600 transition-colors flex items-center justify-center">
                            <svg class="w-4 h-4 mr-2" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M15.75 10.5V6a3.75 3.75 0 10-7.5 0v4.5m11.356-1.993l1.263 12c.07.658-.463 1.243-1.119 1.243H4.25a1.125 1.125 0 01-1.12-1.243l1.264-12A1.125 1.125 0 015.513 7.5h12.974c.576 0 1.059.435 1.119 1.007zM8.625 10.5a.375.375 0 11-.75 0 .375.375 0 01.75 0zm7.5 0a.375.375 0 11-.75 0 .375.375 0 01.75 0z"/>
                            </svg>
                            Agregar
                        </button>
                    </div>
                </div>
            </div>
        `;
    });
    
    html += `</div>`;
    contenedorFavoritos.innerHTML = html;
    
    // Agregar event listeners a los botones de favoritos
    document.querySelectorAll('.favorito-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const productId = parseInt(this.dataset.id);
            toggleFavorito(productId);
            renderizarFavoritos(); // Recargar la lista
        });
    });
}

/**
 * Renderiza productos sugeridos en la página de favoritos
 */
function renderizarProductosSugeridosFavoritos() {
    const contenedorSugeridos = document.getElementById('productos-sugeridos-favoritos');
    if (!contenedorSugeridos) return;
    
    const productosSugeridos = obtenerProductosSugeridos(AppState.favoritos);
    
    if (productosSugeridos.length === 0) {
        contenedorSugeridos.innerHTML = '';
        return;
    }
    
    let html = `
        <div class="mt-20">
            <h2 class="text-2xl font-bold text-brand-800 font-serif mb-6">Quizás te guste</h2>
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
    `;
    
    productosSugeridos.forEach(producto => {
        const esFav = esFavorito(producto.id);
        
        html += `
            <div class="product-card group">
                <div class="relative overflow-hidden rounded-lg">
                    <img src="${producto.imagen}" alt="${producto.nombre}" class="w-full h-64 object-cover transition-transform duration-300 group-hover:scale-105">
                    <div class="absolute top-2 right-2 bg-white/80 backdrop-blur-sm text-brand-700 text-xs font-semibold px-2 py-1 rounded-full">${producto.estado}</div>
                    <button class="favorito-btn-sugerido absolute top-2 left-2 bg-white/80 backdrop-blur-sm p-1.5 rounded-full ${esFav ? 'text-red-500' : 'text-brand-500 hover:text-red-500'} transition-colors"
                            data-id="${producto.id}">
                        <svg class="w-5 h-5" fill="${esFav ? 'currentColor' : 'none'}" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1.5">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M21 8.25c0-2.485-2.099-4.5-4.688-4.5-1.935 0-3.597 1.126-4.312 2.733-.715-1.607-2.377-2.733-4.313-2.733C5.1 3.75 3 5.765 3 8.25c0 7.22 9 12 9 12s9-4.78 9-12z"/>
                        </svg>
                    </button>
                </div>
                <div class="mt-4">
                    <h3 class="font-semibold text-brand-800">${producto.nombre}</h3>
                    <div class="flex justify-between items-center mt-3">
                        <span class="font-bold text-brand-700 text-lg">$${producto.precio}</span>
                        <button onclick="agregarAlCarrito(${producto.id})" class="bg-brand-500 text-white p-2 rounded-full hover:bg-brand-600 transition-colors">
                            <svg class="w-4 h-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M12 4.5v15m7.5-7.5h-15"/>
                            </svg>
                        </button>
                    </div>
                </div>
            </div>
        `;
    });
    
    html += `
            </div>
        </div>
    `;
    
    contenedorSugeridos.innerHTML = html;
    
    // Agregar event listeners a los botones de favoritos en productos sugeridos
    document.querySelectorAll('.favorito-btn-sugerido').forEach(btn => {
        btn.addEventListener('click', function() {
            const productId = parseInt(this.dataset.id);
            toggleFavorito(productId);
            renderizarFavoritos();
            renderizarProductosSugeridosFavoritos();
        });
    });
}

/**
 * Inicializa la funcionalidad de favoritos
 */
function inicializarFavoritos() {
    renderizarFavoritos();
    renderizarProductosSugeridosFavoritos();
}

// Exportar funciones globalmente
window.toggleFavorito = toggleFavorito;
window.esFavorito = esFavorito;
window.obtenerFavoritos = obtenerFavoritos;
window.renderizarFavoritos = renderizarFavoritos;
window.inicializarFavoritos = inicializarFavoritos;