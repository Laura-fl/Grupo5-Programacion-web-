/**
 * Funcionalidades del carrito de compras
 */

/**
 * Agrega un producto al carrito
 */
function agregarAlCarrito(idProducto, talla = 'M', cantidad = 1) {
    const producto = obtenerProducto(idProducto);
    
    if (!producto) {
        mostrarNotificacion('Producto no encontrado', 'error');
        return false;
    }
    
    // Verificar si la talla está disponible
    if (!producto.tallas.includes(talla)) {
        mostrarNotificacion(`Talla ${talla} no disponible para este producto`, 'error');
        return false;
    }
    
    const itemExistente = AppState.carrito.find(item => 
        item.id === idProducto && item.talla === talla
    );
    
    if (itemExistente) {
        itemExistente.cantidad += cantidad;
    } else {
        AppState.carrito.push({
            id: idProducto,
            talla: talla,
            cantidad: cantidad,
            agregadoEn: new Date().toISOString()
        });
    }
    
    guardarEstado();
    mostrarNotificacion('Producto agregado al carrito', 'success');
    return true;
}

/**
 * Elimina un producto del carrito
 */
function eliminarDelCarrito(idProducto, talla) {
    AppState.carrito = AppState.carrito.filter(item => 
        !(item.id === idProducto && item.talla === talla)
    );
    
    guardarEstado();
    mostrarNotificacion('Producto eliminado del carrito', 'info');
}

/**
 * Actualiza la cantidad de un producto en el carrito
 */
function actualizarCantidadCarrito(idProducto, talla, nuevaCantidad) {
    const item = AppState.carrito.find(item => 
        item.id === idProducto && item.talla === talla
    );
    
    if (item) {
        if (nuevaCantidad <= 0) {
            eliminarDelCarrito(idProducto, talla);
        } else {
            item.cantidad = nuevaCantidad;
            guardarEstado();
        }
    }
}

/**
 * Calcula el total del carrito
 */
function calcularTotalCarrito() {
    return AppState.carrito.reduce((total, item) => {
        const producto = obtenerProducto(item.id);
        return total + (producto.precio * item.cantidad);
    }, 0);
}

/**
 * Calcula el ahorro total vs precios originales
 */
function calcularAhorroTotal() {
    return AppState.carrito.reduce((ahorro, item) => {
        const producto = obtenerProducto(item.id);
        return ahorro + ((producto.precioOriginal - producto.precio) * item.cantidad);
    }, 0);
}

/**
 * Calcula el impacto ambiental positivo
 */
function calcularImpactoAmbiental() {
    const impactoPorProducto = AppState.carrito.reduce((impacto, item) => {
        const producto = obtenerProducto(item.id);
        return impacto + (producto.impactoCO2 * item.cantidad);
    }, 0);
    
    // Convertir a kg y redondear
    return Math.round(impactoPorProducto * 10) / 10;
}

/**
 * Vacía el carrito completamente
 */
function vaciarCarrito() {
    AppState.carrito = [];
    guardarEstado();
    mostrarNotificacion('Carrito vaciado', 'info');
}

/**
 * Renderiza el carrito en la página
 */
function renderizarCarrito() {
    const contenedorCarrito = document.getElementById('contenedor-carrito');
    const totalCarrito = document.getElementById('total-carrito');
    const ahorroTotal = document.getElementById('ahorro-total');
    const impactoTotal = document.getElementById('impacto-total');
    const contadorItems = document.getElementById('contador-items');
    
    if (!contenedorCarrito) return;
    
    if (AppState.carrito.length === 0) {
        contenedorCarrito.innerHTML = `
            <div class="text-center py-12">
                <svg class="mx-auto h-16 w-16 text-brand-300" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z"/>
                </svg>
                <h3 class="mt-4 text-lg font-semibold text-brand-700">Tu carrito está vacío</h3>
                <p class="mt-2 text-brand-600">Agrega algunos productos sostenibles a tu carrito.</p>
                <a href="coleccion.html" class="inline-block mt-4 bg-brand-500 text-white px-6 py-2.5 rounded-full font-semibold text-sm hover:bg-brand-600 transition-colors">
                    Explorar Colección
                </a>
            </div>
        `;
        
        if (totalCarrito) totalCarrito.textContent = '$0';
        if (ahorroTotal) ahorroTotal.textContent = '$0';
        if (impactoTotal) impactoTotal.textContent = '0.0kg';
        if (contadorItems) contadorItems.textContent = '0 items';
        
        return;
    }
    
    let html = '';
    let total = 0;
    let ahorro = 0;
    let impacto = 0;
    let totalItems = 0;
    
    AppState.carrito.forEach(item => {
        const producto = obtenerProducto(item.id);
        const subtotal = producto.precio * item.cantidad;
        const subtotalAhorro = (producto.precioOriginal - producto.precio) * item.cantidad;
        
        total += subtotal;
        ahorro += subtotalAhorro;
        impacto += producto.impactoCO2 * item.cantidad;
        totalItems += item.cantidad;
        
        html += `
            <div class="bg-white rounded-2xl p-6 border border-brand-100 shadow-sm" data-item-id="${producto.id}" data-talla="${item.talla}">
                <div class="flex flex-col sm:flex-row gap-4">
                    <div class="flex-shrink-0">
                        <img src="${producto.imagen}" alt="${producto.nombre}" class="w-24 h-24 rounded-lg object-cover">
                    </div>
                    <div class="flex-grow">
                        <h3 class="font-semibold text-brand-800">${producto.nombre}</h3>
                        <div class="flex flex-wrap gap-2 mt-2 text-sm text-brand-600">
                            <span class="bg-brand-100 px-2 py-1 rounded">Talla: ${item.talla}</span>
                            <span class="bg-brand-100 px-2 py-1 rounded">${producto.estado}</span>
                            <span class="bg-green-100 text-green-700 px-2 py-1 rounded">${producto.circularidad}% circular</span>
                        </div>
                        <div class="flex items-center justify-between mt-4">
                            <div class="flex items-center space-x-3">
                                <button class="disminuir-cantidad w-8 h-8 rounded-full border border-brand-200 flex items-center justify-center hover:bg-brand-100 transition-colors" 
                                        data-id="${producto.id}" data-talla="${item.talla}">
                                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 12H4"/>
                                    </svg>
                                </button>
                                <span class="cantidad-actual w-8 text-center font-semibold">${item.cantidad}</span>
                                <button class="aumentar-cantidad w-8 h-8 rounded-full border border-brand-200 flex items-center justify-center hover:bg-brand-100 transition-colors"
                                        data-id="${producto.id}" data-talla="${item.talla}">
                                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/>
                                    </svg>
                                </button>
                            </div>
                            <div class="text-right">
                                <div class="font-bold text-brand-700 text-lg">$${subtotal}</div>
                                <div class="text-sm text-brand-500 line-through">$${producto.precioOriginal * item.cantidad}</div>
                            </div>
                        </div>
                    </div>
                    <button class="eliminar-item flex-shrink-0 w-8 h-8 rounded-full border border-brand-200 flex items-center justify-center hover:bg-red-100 hover:text-red-600 hover:border-red-300 transition-colors"
                            data-id="${producto.id}" data-talla="${item.talla}">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                        </svg>
                    </button>
                </div>
            </div>
        `;
    });
    
    contenedorCarrito.innerHTML = html;
    
    if (totalCarrito) totalCarrito.textContent = `$${total}`;
    if (ahorroTotal) ahorroTotal.textContent = `$${ahorro}`;
    if (impactoTotal) impactoTotal.textContent = `${Math.round(impacto * 10) / 10}kg`;
    if (contadorItems) contadorItems.textContent = `${totalItems} ${totalItems === 1 ? 'item' : 'items'}`;
    
    // Agregar event listeners a los botones
    agregarEventListenersCarrito();
}

/**
 * Agrega event listeners a los elementos del carrito
 */
function agregarEventListenersCarrito() {
    // Botones de aumentar/disminuir cantidad
    document.querySelectorAll('.aumentar-cantidad').forEach(btn => {
        btn.addEventListener('click', function() {
            const id = this.dataset.id;
            const talla = this.dataset.talla;
            const item = AppState.carrito.find(item => item.id == id && item.talla === talla);
            if (item) {
                actualizarCantidadCarrito(parseInt(id), talla, item.cantidad + 1);
                renderizarCarrito();
            }
        });
    });
    
    document.querySelectorAll('.disminuir-cantidad').forEach(btn => {
        btn.addEventListener('click', function() {
            const id = this.dataset.id;
            const talla = this.dataset.talla;
            const item = AppState.carrito.find(item => item.id == id && item.talla === talla);
            if (item && item.cantidad > 1) {
                actualizarCantidadCarrito(parseInt(id), talla, item.cantidad - 1);
                renderizarCarrito();
            }
        });
    });
    
    // Botones de eliminar
    document.querySelectorAll('.eliminar-item').forEach(btn => {
        btn.addEventListener('click', function() {
            const id = this.dataset.id;
            const talla = this.dataset.talla;
            eliminarDelCarrito(parseInt(id), talla);
            renderizarCarrito();
        });
    });
    
    // Botón de vaciar carrito
    const vaciarBtn = document.getElementById('vaciar-carrito');
    if (vaciarBtn) {
        vaciarBtn.addEventListener('click', function() {
            if (confirm('¿Estás seguro de que quieres vaciar el carrito?')) {
                vaciarCarrito();
                renderizarCarrito();
            }
        });
    }
    
    // Botón de proceder al pago
    const pagarBtn = document.getElementById('proceder-pago');
    if (pagarBtn) {
        pagarBtn.addEventListener('click', function() {
            if (AppState.carrito.length === 0) {
                mostrarNotificacion('Tu carrito está vacío', 'error');
                return;
            }
            mostrarNotificacion('Funcionalidad de pago en desarrollo', 'info');
            // Aquí iría la lógica de pago
        });
    }
}

/**
 * Inicializa la funcionalidad del carrito
 */
function inicializarCarrito() {
    renderizarCarrito();
}

// Exportar funciones globalmente
window.agregarAlCarrito = agregarAlCarrito;
window.eliminarDelCarrito = eliminarDelCarrito;
window.actualizarCantidadCarrito = actualizarCantidadCarrito;
window.calcularTotalCarrito = calcularTotalCarrito;
window.calcularAhorroTotal = calcularAhorroTotal;
window.calcularImpactoAmbiental = calcularImpactoAmbiental;
window.vaciarCarrito = vaciarCarrito;
window.renderizarCarrito = renderizarCarrito;
window.inicializarCarrito = inicializarCarrito;