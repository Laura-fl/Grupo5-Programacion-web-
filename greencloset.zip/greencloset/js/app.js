/**
 * GreenCloset - Aplicación de moda circular
 * Maneja la lógica principal de la aplicación
 */

// Estado global de la aplicación
const AppState = {
    carrito: JSON.parse(localStorage.getItem('carrito')) || [],
    favoritos: JSON.parse(localStorage.getItem('favoritos')) || [],
    usuario: JSON.parse(localStorage.getItem('usuario')) || null
};

// Inicialización de la aplicación
document.addEventListener('DOMContentLoaded', function() {
    inicializarApp();
    actualizarContadores();
});

/**
 * Inicializa la aplicación
 */
function inicializarApp() {
    // Mobile menu toggle
    const mobileMenuButton = document.getElementById('mobile-menu-button');
    const mobileMenu = document.getElementById('mobile-menu');
    
    if (mobileMenuButton && mobileMenu) {
        mobileMenuButton.addEventListener('click', () => {
            mobileMenu.classList.toggle('hidden');
        });
    }

    // Cerrar menú móvil al hacer clic en un enlace
    document.querySelectorAll('#mobile-menu a').forEach(link => {
        link.addEventListener('click', () => {
            mobileMenu.classList.add('hidden');
        });
    });

    // Manejar notificaciones de agregado al carrito
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('agregado') === '1') {
        mostrarNotificacion('Producto agregado al carrito', 'success');
    }

    // Inicializar componentes específicos de cada página
    const currentPage = window.location.pathname.split('/').pop();
    
    switch(currentPage) {
        case 'coleccion.html':
            inicializarColeccion();
            break;
        case 'favoritos.html':
            inicializarFavoritos();
            break;
        case 'carrito.html':
            inicializarCarrito();
            break;
        case 'soporte.html':
            inicializarSoporte();
            break;
    }
}

/**
 * Muestra una notificación temporal
 */
function mostrarNotificacion(mensaje, tipo = 'info') {
    const notification = document.createElement('div');
    notification.className = `fixed top-4 right-4 z-50 p-4 rounded-lg shadow-lg transform transition-transform duration-300 ${
        tipo === 'success' ? 'bg-green-500 text-white' : 
        tipo === 'error' ? 'bg-red-500 text-white' : 
        'bg-blue-500 text-white'
    }`;
    notification.textContent = mensaje;
    
    document.body.appendChild(notification);
    
    // Animar entrada
    setTimeout(() => {
        notification.classList.add('translate-x-0');
    }, 10);
    
    // Remover después de 3 segundos
    setTimeout(() => {
        notification.classList.add('translate-x-full');
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 300);
    }, 3000);
}

/**
 * Actualiza los contadores del carrito y favoritos en el header
 */
function actualizarContadores() {
    // Contador del carrito
    const carritoCounters = document.querySelectorAll('.carrito-counter');
    const totalItems = AppState.carrito.reduce((total, item) => total + item.cantidad, 0);
    
    carritoCounters.forEach(counter => {
        counter.textContent = totalItems;
        counter.classList.toggle('hidden', totalItems === 0);
    });

    // Contador de favoritos
    const favoritosCounters = document.querySelectorAll('.favoritos-counter');
    const totalFavoritos = AppState.favoritos.length;
    
    favoritosCounters.forEach(counter => {
        counter.textContent = totalFavoritos;
        counter.classList.toggle('hidden', totalFavoritos === 0);
    });
}

/**
 * Guarda el estado en localStorage
 */
function guardarEstado() {
    localStorage.setItem('carrito', JSON.stringify(AppState.carrito));
    localStorage.setItem('favoritos', JSON.stringify(AppState.favoritos));
    localStorage.setItem('usuario', JSON.stringify(AppState.usuario));
    actualizarContadores();
}
/**
 * Inicializa la funcionalidad de favoritos en productos
 */
function inicializarBotonesFavoritos() {
    // Agregar event listeners a todos los botones de favoritos
    document.addEventListener('click', function(e) {
        if (e.target.closest('.favorito-btn') || e.target.closest('.favorito-btn-sugerido')) {
            const btn = e.target.closest('.favorito-btn') || e.target.closest('.favorito-btn-sugerido');
            const productId = parseInt(btn.dataset.id);
            
            if (productId) {
                toggleFavorito(productId);
                
                // Actualizar el estado visual del botón
                const svg = btn.querySelector('svg');
                const isFav = esFavorito(productId);
                
                if (isFav) {
                    svg.innerHTML = '<path stroke-linecap="round" stroke-linejoin="round" d="M21 8.25c0-2.485-2.099-4.5-4.688-4.5-1.935 0-3.597 1.126-4.312 2.733-.715-1.607-2.377-2.733-4.313-2.733C5.1 3.75 3 5.765 3 8.25c0 7.22 9 12 9 12s9-4.78 9-12z" fill="currentColor"/>';
                    btn.classList.add('text-red-500');
                    btn.classList.remove('text-brand-500');
                } else {
                    svg.innerHTML = '<path stroke-linecap="round" stroke-linejoin="round" d="M21 8.25c0-2.485-2.099-4.5-4.688-4.5-1.935 0-3.597 1.126-4.312 2.733-.715-1.607-2.377-2.733-4.313-2.733C5.1 3.75 3 5.765 3 8.25c0 7.22 9 12 9 12s9-4.78 9-12z"/>';
                    svg.removeAttribute('fill');
                    btn.classList.remove('text-red-500');
                    btn.classList.add('text-brand-500');
                }
            }
        }
    });
}

// Actualizar la función inicializarApp para incluir favoritos
function inicializarApp() {
    // ... código existente ...
    
    inicializarBotonesFavoritos();
    actualizarBotonesFavoritos();
}

/**
 * Actualiza el estado visual de todos los botones de favoritos
 */
function actualizarBotonesFavoritos() {
    document.querySelectorAll('.favorito-btn, .favorito-btn-sugerido').forEach(btn => {
        const productId = parseInt(btn.dataset.id);
        if (productId) {
            const isFav = esFavorito(productId);
            const svg = btn.querySelector('svg');
            
            if (isFav) {
                svg.innerHTML = '<path stroke-linecap="round" stroke-linejoin="round" d="M21 8.25c0-2.485-2.099-4.5-4.688-4.5-1.935 0-3.597 1.126-4.312 2.733-.715-1.607-2.377-2.733-4.313-2.733C5.1 3.75 3 5.765 3 8.25c0 7.22 9 12 9 12s9-4.78 9-12z" fill="currentColor"/>';
                btn.classList.add('text-red-500');
                btn.classList.remove('text-brand-500');
            } else {
                svg.innerHTML = '<path stroke-linecap="round" stroke-linejoin="round" d="M21 8.25c0-2.485-2.099-4.5-4.688-4.5-1.935 0-3.597 1.126-4.312 2.733-.715-1.607-2.377-2.733-4.313-2.733C5.1 3.75 3 5.765 3 8.25c0 7.22 9 12 9 12s9-4.78 9-12z"/>';
                svg.removeAttribute('fill');
                btn.classList.remove('text-red-500');
                btn.classList.add('text-brand-500');
            }
        }
    });
}

// Exportar para uso en otros archivos
window.AppState = AppState;
window.mostrarNotificacion = mostrarNotificacion;
window.guardarEstado = guardarEstado;